import { createClientFromRequest } from 'npm:@base44/sdk@0.8.54';

export default async function (req) {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me().catch((e) => (e.status === 401 ? null : Promise.reject(e)));
    if (!user) {
      return Response.json({ error: 'Please sign in to read a label.' }, { status: 401 });
    }

    const body = await req.json().catch(() => ({}));
    const imageUrl = typeof body.image_url === 'string' ? body.image_url.trim() : '';
    if (!imageUrl || !/^https?:\/\//i.test(imageUrl) || imageUrl.length > 2000) {
      return Response.json({ error: 'image_url must be a valid image link' }, { status: 400 });
    }

    const result = await base44.asServiceRole.integrations.Core.InvokeLLM({
      prompt: `You are reading a photograph of an Indian medicine strip, blister pack or box.

1. Read all the printed text on the packaging.
2. Identify the BRAND NAME of the medicine (the large product name, for example "Crocin 500", "Dolo 650", "Pan 40", "Azithral 500"). Ignore the manufacturer name, batch number, manufacturing and expiry dates, MRP, and phrases like "store below 30 C".
3. Read the strength (for example 500 mg, 650 mg, 40 mg, 10 mg, 50 mcg).
4. Give up to 3 spelling variants of the brand name, most likely first — image text is often slightly blurred or partly covered, so include the closest well-known Indian brand names that fit.

If the image does not show a medicine at all, return an empty detected_name and an empty candidates list.

Respond only with the requested JSON.`,
      file_urls: [imageUrl],
      response_json_schema: {
        type: 'object',
        properties: {
          raw_text: { type: 'string', description: 'All readable text from the packaging' },
          detected_name: { type: 'string', description: 'Most likely brand name, e.g. Crocin 500' },
          strength: { type: 'string', description: 'e.g. 500 mg, or empty string' },
          candidates: {
            type: 'array',
            items: { type: 'string' },
            description: 'Up to 3 brand name variants, most likely first',
          },
        },
        required: ['raw_text', 'detected_name', 'strength', 'candidates'],
      },
    });

    const payload = result && typeof result === 'object' ? result : {};

    return Response.json({
      raw_text: typeof payload.raw_text === 'string' ? payload.raw_text.slice(0, 3000) : '',
      detected_name: typeof payload.detected_name === 'string' ? payload.detected_name.slice(0, 120) : '',
      strength: typeof payload.strength === 'string' ? payload.strength.slice(0, 40) : '',
      candidates: Array.isArray(payload.candidates)
        ? payload.candidates.filter((item) => typeof item === 'string').slice(0, 3)
        : [],
    });
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
}