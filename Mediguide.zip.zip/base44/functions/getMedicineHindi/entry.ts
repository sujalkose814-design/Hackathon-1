import { createClientFromRequest } from 'npm:@base44/sdk@0.8.54';

export default async function (req) {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me().catch((e) => (e.status === 401 ? null : Promise.reject(e)));
    if (!user) {
      return Response.json({ error: 'Please sign in to continue.' }, { status: 401 });
    }

    const body = await req.json().catch(() => ({}));
    const infoId = typeof body.info_id === 'string' ? body.info_id : '';
    if (!infoId) {
      return Response.json({ error: 'info_id is required' }, { status: 400 });
    }

    const info = await base44.entities.MedicineInfo.get(infoId).catch((e) =>
      e.status === 404 ? null : Promise.reject(e),
    );
    if (!info) {
      return Response.json({ error: 'Medicine not found' }, { status: 404 });
    }

    const existingUses = Array.isArray(info.hindi_uses) ? info.hindi_uses : [];
    if (existingUses.length > 0 && info.hindi_dosage) {
      return Response.json({
        hindi_uses: existingUses,
        hindi_dosage: info.hindi_dosage,
        hindi_warnings: Array.isArray(info.hindi_warnings) ? info.hindi_warnings : [],
      });
    }

    const translated = await base44.asServiceRole.integrations.Core.InvokeLLM({
      prompt: `Translate this medicine information into simple, everyday Hindi in Devanagari script, for an elderly patient in India.

Rules:
- Use short, natural spoken Hindi, the way a pharmacist would explain it.
- Keep all numbers and units in digits, for example "500 मिलीग्राम", "1 गोली".
- Do not add any new medical advice, and do not leave anything in English.
- Keep the same number of uses and warnings as given.

Salt: ${info.generic_name} ${info.strength}
Uses: ${(info.uses || []).join('; ') || 'not listed'}
Dosage: ${info.dosage || 'not listed'}
Warnings: ${(info.warnings || []).join('; ') || 'not listed'}`,
      response_json_schema: {
        type: 'object',
        properties: {
          hindi_uses: { type: 'array', items: { type: 'string' } },
          hindi_dosage: { type: 'string' },
          hindi_warnings: { type: 'array', items: { type: 'string' } },
        },
        required: ['hindi_uses', 'hindi_dosage', 'hindi_warnings'],
      },
    });

    const payload = {
      hindi_uses: Array.isArray(translated?.hindi_uses)
        ? translated.hindi_uses.filter((item) => typeof item === 'string').slice(0, 8)
        : [],
      hindi_dosage: typeof translated?.hindi_dosage === 'string' ? translated.hindi_dosage : '',
      hindi_warnings: Array.isArray(translated?.hindi_warnings)
        ? translated.hindi_warnings.filter((item) => typeof item === 'string').slice(0, 8)
        : [],
    };

    if (payload.hindi_uses.length > 0 || payload.hindi_dosage) {
      await base44.entities.MedicineInfo.update(infoId, payload);
    }

    return Response.json(payload);
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
}