import React, { useMemo, useState } from 'react';
import { Type } from 'lucide-react';
import MatchList from '@/components/MatchList';
import { findMatches } from '@/lib/fuzzyMatch';

export default function ManualSearch({ medicines, onPick }) {
  const [query, setQuery] = useState('');

  const matches = useMemo(
    () => (query.trim().length >= 2 ? findMatches(query, medicines, 5) : []),
    [query, medicines],
  );

  return (
    <section className="rounded-3xl border border-border bg-card p-5 shadow-sm sm:p-6">
      <div className="flex items-center gap-2.5">
        <span className="grid h-9 w-9 place-items-center rounded-xl bg-secondary text-secondary-foreground">
          <Type className="h-5 w-5" />
        </span>
        <h2 className="font-heading text-xl font-extrabold tracking-tight">Type the medicine name</h2>
      </div>
      <input
        value={query}
        onChange={(event) => setQuery(event.target.value)}
        placeholder="For example: Dolo 650, Crocin 500, Pan 40"
        autoComplete="off"
        className="mt-3 h-16 w-full rounded-2xl border-2 border-input bg-background px-5 text-xl font-medium text-foreground placeholder:text-muted-foreground/70 focus:border-primary focus:outline-none focus:ring-4 focus:ring-ring/15"
      />
      {query.trim().length >= 2 && matches.length === 0 && (
        <p className="mt-3 rounded-2xl bg-muted px-4 py-3 text-base text-muted-foreground">
          No match found. Check the spelling, or type the salt name (for example “paracetamol”).
        </p>
      )}
      <MatchList matches={matches} onPick={onPick} title={matches.length ? 'Likely matches' : undefined} />
    </section>
  );
}