import React, { useState } from 'react';
import { Camera, Type } from 'lucide-react';
import PhotoScan from '@/components/PhotoScan';
import ManualSearch from '@/components/ManualSearch';
import { cn } from '@/lib/utils';

const MODES = [
  { id: 'photo', label: 'Photo of strip', icon: Camera },
  { id: 'type', label: 'Type name', icon: Type },
];

export default function ScanSection({ medicines, onPick }) {
  const [mode, setMode] = useState('photo');

  return (
    <div>
      <div className="mb-3 grid grid-cols-2 gap-2 rounded-2xl border border-border bg-card p-2">
        {MODES.map((item) => (
          <button
            key={item.id}
            type="button"
            onClick={() => setMode(item.id)}
            className={cn(
              'flex items-center justify-center gap-2 rounded-xl px-3 py-3 text-base font-bold transition',
              mode === item.id
                ? 'bg-primary text-primary-foreground shadow-sm'
                : 'text-muted-foreground hover:bg-secondary',
            )}
          >
            <item.icon className="h-5 w-5" />
            {item.label}
          </button>
        ))}
      </div>

      {mode === 'photo' ? (
        <PhotoScan medicines={medicines} onPick={onPick} />
      ) : (
        <ManualSearch medicines={medicines} onPick={onPick} />
      )}
    </div>
  );
}