import React from 'react';
import { BookOpen, Camera, IndianRupee, ScanLine } from 'lucide-react';

const STEPS = [
  {
    icon: Camera,
    title: 'Photograph the strip',
    body: 'Hold the strip steady in good light and take a photo of the printed name.',
  },
  {
    icon: ScanLine,
    title: 'We read the text',
    body: 'The label is read and the brand name is matched even when a few letters are unclear.',
  },
  {
    icon: BookOpen,
    title: 'Understand the medicine',
    body: 'Salt, uses, dose, side effects and warnings — in English and Hindi.',
  },
  {
    icon: IndianRupee,
    title: 'Compare generics',
    body: 'Other brands with the same salt and strength, sorted by price.',
  },
];

export default function HowItWorks() {
  return (
    <section className="mt-10">
      <h2 className="font-heading text-2xl font-extrabold tracking-tight">How it works</h2>
      <div className="mt-4 grid gap-3 sm:grid-cols-2">
        {STEPS.map((step, index) => (
          <div key={step.title} className="rounded-2xl border border-border bg-card p-5">
            <div className="flex items-center gap-2.5">
              <span className="grid h-9 w-9 place-items-center rounded-xl bg-secondary text-sm font-extrabold text-secondary-foreground">
                {index + 1}
              </span>
              <step.icon className="h-5 w-5 text-primary" />
              <h3 className="font-heading text-base font-extrabold">{step.title}</h3>
            </div>
            <p className="mt-2 text-base leading-relaxed text-muted-foreground">{step.body}</p>
          </div>
        ))}
      </div>
    </section>
  );
}