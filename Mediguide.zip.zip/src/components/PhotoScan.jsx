import React, { useRef, useState } from 'react';
import { Camera, CircleAlert, Loader2, RefreshCcw, ScanLine } from 'lucide-react';
import { base44 } from '@/api/base44Client';
import { Image } from '@/components/ui/image';
import MatchList from '@/components/MatchList';
import { resolveLabelMatches } from '@/lib/fuzzyMatch';

export default function PhotoScan({ medicines, onPick }) {
  const inputRef = useRef(null);
  const [preview, setPreview] = useState('');
  const [status, setStatus] = useState('idle');
  const [matches, setMatches] = useState([]);
  const [rawText, setRawText] = useState('');
  const [detected, setDetected] = useState('');
  const [error, setError] = useState('');

  const reset = () => {
    setPreview('');
    setMatches([]);
    setRawText('');
    setDetected('');
    setError('');
    setStatus('idle');
  };

  const handleFile = async (event) => {
    const input = event.target;
    const file = input.files?.[0];
    if (!file) return;

    setError('');
    setMatches([]);
    setRawText('');
    setDetected('');
    setStatus('uploading');

    try {
      const { file_uri } = await base44.integrations.Core.UploadPrivateFile({ file });
      const { signed_url } = await base44.integrations.Core.CreateFileSignedUrl({
        file_uri,
        expires_in: 900,
      });
      setPreview(signed_url);
      setStatus('reading');

      const response = await base44.functions.invoke('readMedicineLabel', {
        image_url: signed_url,
      });
      const label = response.data || {};
      setDetected(label.detected_name || '');
      setRawText(label.raw_text || '');

      const found = resolveLabelMatches(label, medicines, 4);
      setMatches(found);
      setStatus(found.length ? 'done' : 'no-match');
    } catch (err) {
      setError(
        err?.response?.data?.error || err?.message || 'Could not read the label. Please try again.',
      );
      setStatus('error');
    } finally {
      input.value = '';
    }
  };

  const busy = status === 'uploading' || status === 'reading';

  return (
    <section className="rounded-3xl border border-border bg-card p-5 shadow-sm sm:p-6">
      <div className="flex items-center gap-2.5">
        <span className="grid h-9 w-9 place-items-center rounded-xl bg-secondary text-secondary-foreground">
          <Camera className="h-5 w-5" />
        </span>
        <h2 className="font-heading text-xl font-extrabold tracking-tight">Photograph the strip</h2>
      </div>

      <input
        ref={inputRef}
        type="file"
        accept="image/*"
        capture="environment"
        onChange={handleFile}
        className="hidden"
      />

      {!preview ? (
        <button
          type="button"
          onClick={() => inputRef.current?.click()}
          disabled={busy}
          className="mt-3 flex w-full flex-col items-center gap-2 rounded-2xl border-2 border-dashed border-input bg-background px-5 py-9 text-center transition hover:border-primary hover:bg-secondary disabled:opacity-60"
        >
          <span className="grid h-14 w-14 place-items-center rounded-2xl bg-primary text-primary-foreground">
            <Camera className="h-7 w-7" />
          </span>
          <span className="font-heading text-lg font-extrabold">Take or upload a photo</span>
          <span className="max-w-xs text-base text-muted-foreground">
            Keep the brand name in focus and fill the frame with the strip.
          </span>
        </button>
      ) : (
        <div className="mt-3 overflow-hidden rounded-2xl border border-border">
          <Image
            src={preview}
            alt="Photo of the medicine strip you uploaded"
            className="h-44 w-full bg-muted"
            fittingType="fill"
          />
        </div>
      )}

      {busy && (
        <p className="mt-3 flex items-center gap-2 rounded-2xl bg-secondary px-4 py-3 text-base font-semibold text-secondary-foreground">
          <Loader2 className="h-5 w-5 animate-spin" />
          {status === 'uploading' ? 'Uploading your photo…' : 'Reading the label and matching the name…'}
        </p>
      )}

      {preview && !busy && (
        <button
          type="button"
          onClick={() => {
            reset();
            inputRef.current?.click();
          }}
          className="mt-3 inline-flex items-center gap-2 rounded-full border border-border px-4 py-2.5 text-base font-semibold transition hover:bg-secondary"
        >
          <RefreshCcw className="h-4 w-4" />
          Take another photo
        </button>
      )}

      {error && (
        <p className="mt-3 flex items-start gap-2 rounded-2xl bg-destructive/10 px-4 py-3 text-base font-medium text-destructive">
          <CircleAlert className="mt-0.5 h-5 w-5 shrink-0" />
          {error}
        </p>
      )}

      {status === 'done' && (
        <>
          {detected && (
            <p className="mt-4 flex items-center gap-2 text-base text-muted-foreground">
              <ScanLine className="h-4 w-4 shrink-0" />
              Label read as <b className="text-foreground">{detected}</b>
            </p>
          )}
          <MatchList matches={matches} onPick={onPick} title="Tap your medicine to see the details" />
        </>
      )}

      {status === 'no-match' && (
        <div className="mt-4 rounded-2xl bg-muted px-4 py-3 text-base text-muted-foreground">
          <p className="font-semibold text-foreground">Could not match this label.</p>
          <p className="mt-1">
            Try a closer photo of just the brand name, or switch to “Type name” and enter it
            manually.
          </p>
        </div>
      )}

      {rawText && (
        <details className="mt-3 rounded-2xl border border-border px-4 py-3">
          <summary className="cursor-pointer text-sm font-semibold text-muted-foreground">
            Text read from the label
          </summary>
          <p className="mt-2 whitespace-pre-wrap text-sm leading-relaxed text-muted-foreground">
            {rawText}
          </p>
        </details>
      )}
    </section>
  );
}