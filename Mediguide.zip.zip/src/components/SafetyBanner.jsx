import React from 'react';
import { AlertTriangle, Stethoscope } from 'lucide-react';

export default function SafetyBanner() {
  return (
    <div className="rounded-3xl border-2 border-warn-border bg-warn p-5 text-warn-foreground">
      <div className="flex items-start gap-3">
        <AlertTriangle className="mt-0.5 h-6 w-6 shrink-0" />
        <div>
          <p className="font-heading text-lg font-extrabold">
            Ask a doctor or pharmacist before switching any medicine.
          </p>
          <p className="mt-1 text-base leading-relaxed">
            A cheaper brand with the same salt can behave differently (fillers, coating, release
            time). Your doctor knows your condition, kidney and liver health, and other medicines
            you take.
          </p>
          <p className="mt-2 font-hindi text-base leading-relaxed">
            कोई भी दवा बदलने से पहले डॉक्टर या फार्मासिस्ट से सलाह लें।
          </p>
          <p className="mt-3 inline-flex items-center gap-1.5 rounded-full bg-warn-foreground/10 px-3 py-1.5 text-sm font-semibold">
            <Stethoscope className="h-4 w-4" />
            In an emergency, call your doctor or go to the nearest hospital.
          </p>
        </div>
      </div>
    </div>
  );
}