import React from 'react';
import { Link } from 'react-router-dom';
import { Pill, ShieldCheck } from 'lucide-react';

export default function PageShell({ children }) {
  return (
    <div className="min-h-screen bg-background text-foreground">
      <header className="sticky top-0 z-30 border-b border-border bg-background/90 backdrop-blur">
        <div className="mx-auto flex w-full max-w-3xl items-center justify-between gap-3 px-4 py-3">
          <Link to="/" className="flex items-center gap-2.5">
            <span className="grid h-11 w-11 place-items-center rounded-2xl bg-primary text-primary-foreground shadow-sm">
              <Pill className="h-6 w-6" />
            </span>
            <span className="leading-none">
              <span className="block font-heading text-[1.35rem] font-extrabold tracking-tight">
                MEDIGUIDE
              </span>
              <span className="mt-1 block text-xs font-medium text-muted-foreground">
                Medicine, made clear
              </span>
            </span>
          </Link>
          <span className="hidden items-center gap-1.5 rounded-full bg-secondary px-3 py-1.5 text-xs font-semibold text-secondary-foreground sm:inline-flex">
            <ShieldCheck className="h-4 w-4" />
            Guidance only
          </span>
        </div>
      </header>

      <main className="mx-auto w-full max-w-3xl px-4 pb-16 pt-6">{children}</main>

      <footer className="border-t border-border bg-card">
        <div className="mx-auto w-full max-w-3xl px-4 py-6">
          <p className="text-base font-semibold text-foreground">
            Always ask a doctor or pharmacist before starting or switching any medicine.
          </p>
          <p className="mt-1 text-sm text-muted-foreground">
            MEDIGUIDE shares general information from a public medicine dataset. It is not a
            prescription and does not replace medical advice.
          </p>
        </div>
      </footer>
    </div>
  );
}