import React from 'react';
import { ScanLine } from 'lucide-react';

export default function Hero() {
  return (
    <section className="pb-6 pt-1">
      <span className="inline-flex items-center gap-2 rounded-full bg-secondary px-3.5 py-1.5 text-sm font-semibold text-secondary-foreground">
        <ScanLine className="h-4 w-4" />
        Scan · Understand · Compare
      </span>
      <h1 className="mt-4 font-heading text-[2.15rem] font-extrabold leading-[1.08] tracking-tight sm:text-5xl">
        Know your medicine
        <br />
        <span className="text-primary">before you take it.</span>
      </h1>
      <p className="mt-3 max-w-xl text-lg leading-relaxed text-muted-foreground">
        Show the strip or type the name — MEDIGUIDE tells you what it is used for, its salt, dose
        and warnings, then finds cheaper generics with the same salt and strength.
      </p>
    </section>
  );
}