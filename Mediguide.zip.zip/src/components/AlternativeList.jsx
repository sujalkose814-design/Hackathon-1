import React from 'react';
import { ArrowDownRight, IndianRupee } from 'lucide-react';
import { formatINR, percentLess } from '@/lib/format';
import { findAlternatives } from '@/lib/medicines';

export default function AlternativeList({ medicine, all, onPick }) {
  const alternatives = findAlternatives(medicine, all);
  const cheapest = alternatives[0];
  const cheaper = alternatives.filter((item) => item.price < medicine.price);

  return (
    <div className="rounded-3xl border border-border bg-card p-5">
      <div className="flex items-center gap-2.5">
        <IndianRupee className="h-5 w-5 text-primary" />
        <h3 className="font-heading text-xl font-extrabold">Cheaper generics</h3>
      </div>
      <p className="mt-1 text-base text-muted-foreground">
        Same salt <b className="text-foreground">{medicine.generic_name}</b> and same strength{' '}
        <b className="text-foreground">{medicine.strength}</b>.
      </p>

      {alternatives.length === 0 ? (
        <p className="mt-4 rounded-2xl bg-muted px-4 py-3 text-base text-muted-foreground">
          No other brand with this salt and strength in the dataset yet.
        </p>
      ) : (
        <ul className="mt-4 space-y-2.5">
          {alternatives.map((item) => {
            const saving = medicine.price - item.price;
            return (
              <li key={item.id}>
                <button
                  type="button"
                  onClick={() => onPick(item, null)}
                  className="flex w-full items-center justify-between gap-3 rounded-2xl border border-border px-4 py-3.5 text-left transition hover:border-primary hover:bg-secondary"
                >
                  <span className="min-w-0">
                    <span className="block font-heading text-lg font-extrabold leading-tight">
                      {item.brand_name}
                    </span>
                    <span className="mt-0.5 block truncate text-sm text-muted-foreground">
                      {item.manufacturer} · {item.pack_size}
                    </span>
                  </span>
                  <span className="shrink-0 text-right">
                    <span className="block font-heading text-lg font-extrabold">
                      {formatINR(item.price)}
                    </span>
                    {saving > 0 ? (
                      <span className="mt-0.5 inline-flex items-center gap-1 text-sm font-bold text-primary">
                        <ArrowDownRight className="h-4 w-4" />
                        Save {formatINR(saving)}
                      </span>
                    ) : (
                      <span className="mt-0.5 block text-sm text-muted-foreground">Same price</span>
                    )}
                  </span>
                </button>
              </li>
            );
          })}
        </ul>
      )}

      {cheapest && medicine.price > cheapest.price && (
        <p className="mt-3 rounded-2xl bg-secondary px-4 py-3 text-base font-semibold text-secondary-foreground">
          Cheapest option: {cheapest.brand_name} at {formatINR(cheapest.price)} —{' '}
          {percentLess(medicine.price, cheapest.price)}% less than {medicine.brand_name}.
        </p>
      )}
      {alternatives.length > 0 && cheaper.length === 0 && (
        <p className="mt-3 rounded-2xl bg-secondary px-4 py-3 text-base text-secondary-foreground">
          {medicine.brand_name} is already the cheapest brand in our dataset.
        </p>
      )}
    </div>
  );
}