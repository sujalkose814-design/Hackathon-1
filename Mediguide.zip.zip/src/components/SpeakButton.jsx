import React from 'react';
import { Loader2, Square, Volume2 } from 'lucide-react';
import useHindiSpeech from '@/hooks/useHindiSpeech';
import { cn } from '@/lib/utils';

export default function SpeakButton({ text, label = 'सुनें', loading = false, className }) {
  const { speak, stop, speaking, supported } = useHindiSpeech();

  if (!supported) return null;

  const disabled = loading || !text;

  return (
    <button
      type="button"
      disabled={disabled}
      onClick={() => (speaking ? stop() : speak(text))}
      className={cn(
        'inline-flex items-center gap-2 rounded-full bg-primary px-4 py-2.5 text-base font-semibold text-primary-foreground transition hover:opacity-90 disabled:cursor-not-allowed disabled:opacity-50',
        className,
      )}
    >
      {loading ? (
        <Loader2 className="h-5 w-5 animate-spin" />
      ) : speaking ? (
        <Square className="h-4 w-4" />
      ) : (
        <Volume2 className="h-5 w-5" />
      )}
      <span className="font-hindi">{speaking ? 'रोकें' : label}</span>
    </button>
  );
}