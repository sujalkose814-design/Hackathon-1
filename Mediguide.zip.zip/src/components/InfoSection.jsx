import React from 'react';
import { cn } from '@/lib/utils';

export default function InfoSection({ icon: Icon, title, items, text, tone = 'default' }) {
  const hasContent = (items && items.length > 0) || text;
  return (
    <div
      className={cn(
        'rounded-2xl border p-5',
        tone === 'warn' ? 'border-warn-border bg-warn' : 'border-border bg-card',
      )}
    >
      <div className="flex items-center gap-2.5">
        <Icon className={cn('h-5 w-5 shrink-0', tone === 'warn' ? 'text-warn-foreground' : 'text-primary')} />
        <h3 className={cn('font-heading text-lg font-extrabold', tone === 'warn' && 'text-warn-foreground')}>
          {title}
        </h3>
      </div>
      <div className={cn('mt-2.5 space-y-1.5 text-[1.05rem] leading-relaxed', tone === 'warn' && 'text-warn-foreground')}>
        {text && <p>{text}</p>}
        {hasContent &&
          items?.map((item, index) => (
            <p key={index} className="flex gap-2">
              <span className={cn('mt-2 h-1.5 w-1.5 shrink-0 rounded-full', tone === 'warn' ? 'bg-warn-foreground' : 'bg-primary')} />
              <span>{item}</span>
            </p>
          ))}
        {!hasContent && <p className="text-muted-foreground">Not listed for this medicine.</p>}
      </div>
    </div>
  );
}