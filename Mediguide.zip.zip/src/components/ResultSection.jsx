import React, { useEffect, useState } from 'react';
import { AlertCircle, Building2, FlaskConical, Info, Pill, ShieldX, Stethoscope } from 'lucide-react';
import InfoSection from '@/components/InfoSection';
import AlternativeList from '@/components/AlternativeList';
import SpeakButton from '@/components/SpeakButton';
import SafetyBanner from '@/components/SafetyBanner';
import { ensureHindi } from '@/lib/medicines';
import { formatINR } from '@/lib/format';

function Chip({ icon: Icon, children }) {
  return (
    <span className="inline-flex items-center gap-1.5 rounded-full bg-secondary px-3 py-1.5 text-sm font-semibold text-secondary-foreground">
      {Icon && <Icon className="h-4 w-4" />}
      {children}
    </span>
  );
}

export default function ResultSection({ medicine, all, matchNote, onPick }) {
  const [hindi, setHindi] = useState({ uses: [], dosage: '', warnings: [] });
  const [hindiLoading, setHindiLoading] = useState(true);

  useEffect(() => {
    let active = true;
    setHindiLoading(true);
    setHindi({ uses: [], dosage: '', warnings: [] });
    ensureHindi(medicine)
      .then((value) => {
        if (active) setHindi(value);
      })
      .catch(() => {})
      .finally(() => {
        if (active) setHindiLoading(false);
      });
    return () => {
      active = false;
    };
  }, [medicine]);

  const speakText = [
    `${medicine.brand_name}.`,
    medicine.hindi_uses?.length ? `उपयोग: ${hindi.uses.join(', ')}।` : '',
    hindi.dosage ? `खुराक: ${hindi.dosage}` : '',
  ]
    .filter(Boolean)
    .join(' ');

  const warningSpeakText = hindi.warnings?.length
    ? `सावधानी: ${hindi.warnings.join(' ')}`
    : '';

  return (
    <section className="mt-6 space-y-3.5">
      {matchNote && (
        <p className="flex items-start gap-2 rounded-2xl bg-secondary px-4 py-3 text-base text-secondary-foreground">
          <Info className="mt-0.5 h-4 w-4 shrink-0" />
          {matchNote}
        </p>
      )}

      <div className="rounded-3xl border border-border bg-card p-5 shadow-sm sm:p-6">
        <div className="flex flex-wrap items-start justify-between gap-3">
          <div className="min-w-0">
            <div className="flex flex-wrap items-center gap-2">
              <h2 className="font-heading text-[1.85rem] font-extrabold leading-tight tracking-tight sm:text-4xl">
                {medicine.brand_name}
              </h2>
              <span
                className={
                  medicine.prescription_required
                    ? 'rounded-full bg-destructive px-2.5 py-1 text-xs font-bold text-destructive-foreground'
                    : 'rounded-full bg-primary/10 px-2.5 py-1 text-xs font-bold text-primary'
                }
              >
                {medicine.prescription_required ? 'Rx — prescription needed' : 'OTC — no prescription'}
              </span>
            </div>
            <p className="mt-1.5 text-lg text-muted-foreground">
              {medicine.generic_name} · {medicine.strength} · {medicine.form}
            </p>
          </div>
          <div className="text-right">
            <p className="font-heading text-2xl font-extrabold">{formatINR(medicine.price)}</p>
            <p className="text-sm text-muted-foreground">{medicine.pack_size}</p>
          </div>
        </div>

        <div className="mt-4 flex flex-wrap gap-2">
          <Chip icon={FlaskConical}>{medicine.generic_name}</Chip>
          <Chip icon={Building2}>{medicine.manufacturer}</Chip>
          <Chip icon={Stethoscope}>{medicine.form}</Chip>
        </div>

        <div className="mt-5 rounded-2xl bg-secondary p-4">
          <div className="flex flex-wrap items-center justify-between gap-3">
            <p className="font-hindi text-base font-semibold text-secondary-foreground">
              सुनें — उपयोग और खुराक हिंदी में
            </p>
            <SpeakButton text={speakText} loading={hindiLoading} />
          </div>
          {hindi.dosage ? (
            <p className="mt-2 font-hindi text-base leading-relaxed text-secondary-foreground">
              {hindi.dosage}
            </p>
          ) : (
            !hindiLoading && (
              <p className="mt-2 text-sm text-muted-foreground">
                Hindi audio is not available for this medicine yet.
              </p>
            )
          )}
        </div>
      </div>

      <div className="grid gap-3.5 sm:grid-cols-2">
        <InfoSection icon={Pill} title="What it is used for" items={medicine.uses} />
        <InfoSection icon={Stethoscope} title="Dosage" text={medicine.dosage} />
        <InfoSection icon={AlertCircle} title="Common side effects" items={medicine.side_effects} />
        <InfoSection icon={ShieldX} title="Do not take if" items={medicine.contraindications} />
      </div>

      <div className="rounded-2xl border-2 border-warn-border bg-warn p-5 text-warn-foreground">
        <div className="flex items-center gap-2.5">
          <AlertCircle className="h-5 w-5" />
          <h3 className="font-heading text-lg font-extrabold">Warnings</h3>
        </div>
        <div className="mt-2.5 space-y-1.5 text-[1.05rem] leading-relaxed">
          {medicine.warnings?.map((warning, index) => (
            <p key={index} className="flex gap-2">
              <span className="mt-2 h-1.5 w-1.5 shrink-0 rounded-full bg-warn-foreground" />
              <span>{warning}</span>
            </p>
          ))}
        </div>

        <div className="mt-4 rounded-2xl border border-warn-border/60 bg-background/60 p-4">
          <div className="flex flex-wrap items-center justify-between gap-3">
            <p className="font-hindi text-base font-bold">सावधानियाँ (हिंदी में)</p>
            <SpeakButton text={warningSpeakText} label="सुनें" loading={hindiLoading} />
          </div>
          <div className="mt-2 space-y-1.5 font-hindi text-base leading-relaxed">
            {hindi.warnings?.length ? (
              hindi.warnings.map((warning, index) => (
                <p key={index} className="flex gap-2">
                  <span className="mt-2 h-1.5 w-1.5 shrink-0 rounded-full bg-warn-foreground" />
                  <span>{warning}</span>
                </p>
              ))
            ) : (
              <p className="text-sm">
                {hindiLoading ? 'हिंदी अनुवाद तैयार हो रहा है…' : 'No Hindi translation available.'}
              </p>
            )}
          </div>
        </div>
      </div>

      <SafetyBanner />

      <AlternativeList medicine={medicine} all={all} onPick={onPick} />
    </section>
  );
}