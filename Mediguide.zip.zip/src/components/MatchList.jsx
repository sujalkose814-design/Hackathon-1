import React from 'react';
import { ChevronRight } from 'lucide-react';
import { formatINR } from '@/lib/format';

export default function MatchList({ matches = [], onPick, title }) {
  if (!matches.length) return null;
  return (
    <div className="mt-4">
      {title && <p className="mb-2 text-sm font-semibold text-muted-foreground">{title}</p>}
      <ul className="overflow-hidden rounded-2xl border border-border bg-card">
        {matches.map(({ medicine, score }, index) => (
          <li key={medicine.id} className={index > 0 ? 'border-t border-border' : ''}>
            <button
              type="button"
              onClick={() => onPick(medicine, score)}
              className="flex w-full items-center justify-between gap-3 px-4 py-4 text-left transition hover:bg-secondary"
            >
              <span className="min-w-0">
                <span className="block font-heading text-lg font-extrabold leading-tight">
                  {medicine.brand_name}
                </span>
                <span className="mt-0.5 block truncate text-sm text-muted-foreground">
                  {medicine.generic_name} · {medicine.strength} · {formatINR(medicine.price)}
                </span>
              </span>
              <span className="flex shrink-0 items-center gap-2">
                <span className="rounded-full bg-secondary px-2.5 py-1 text-xs font-bold text-secondary-foreground">
                  {Math.round(score * 100)}%
                </span>
                <ChevronRight className="h-5 w-5 text-muted-foreground" />
              </span>
            </button>
          </li>
        ))}
      </ul>
    </div>
  );
}