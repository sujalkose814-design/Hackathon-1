import React, { useEffect, useRef, useState } from 'react';
import PageShell from '@/components/PageShell';
import Hero from '@/components/Hero';
import ScanSection from '@/components/ScanSection';
import ResultSection from '@/components/ResultSection';
import HowItWorks from '@/components/HowItWorks';
import { loadMedicines } from '@/lib/medicines';

export default function Home() {
  const [medicines, setMedicines] = useState([]);
  const [selected, setSelected] = useState(null);
  const [matchNote, setMatchNote] = useState('');
  const resultRef = useRef(null);

  useEffect(() => {
    loadMedicines().then(setMedicines);
  }, []);

  const handlePick = (medicine, score) => {
    setSelected(medicine);
    setMatchNote(
      score && score < 0.99
        ? `Matched to ${medicine.brand_name} — ${Math.round(score * 100)}% confidence. If this is not your medicine, try typing the name.`
        : '',
    );
    setTimeout(() => {
      resultRef.current?.scrollIntoView({ behavior: 'smooth', block: 'start' });
    }, 60);
  };

  return (
    <PageShell>
      <Hero />
      <ScanSection medicines={medicines} onPick={handlePick} />
      <div ref={resultRef} className="scroll-mt-24" />
      {selected && (
        <ResultSection
          medicine={selected}
          all={medicines}
          matchNote={matchNote}
          onPick={handlePick}
        />
      )}
      <HowItWorks />
    </PageShell>
  );
}